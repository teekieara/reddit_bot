import re

def extract_wait_time(error_message):
    """
    Extract the wait time from an error message.
    Args:
        error_message (str): The error message containing rate limit information.
    Returns:
        int: The wait time in seconds. Defaults to 60 seconds if no time is found.
    """
    match = re.search(r"(\d+)\s*(minute|second)", error_message, re.IGNORECASE)
    if match:
        wait_time = int(match.group(1))
        if "minute" in match.group(2).lower():
            wait_time *= 60  # Convert minutes to seconds
        return wait_time
    return 60  # Default wait time

