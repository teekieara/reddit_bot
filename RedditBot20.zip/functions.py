import logging
import json
from utils import extract_wait_time
from debugging import debug_print

def some_function():
    debug_print("Starting some_function...")
    # Function logic
    debug_print("Finished some_function.")


def load_file(file_path):
    try:
        if file_path.endswith('.json'):  # Check if the file is JSON
            with open(file_path, "r") as file:
               return json.load(file)  # Parse JSON content
        else:  # Assume it's a text file
            with open(file_path, "r") as file:
                return file.read().splitlines()  # Split lines for text files
    except FileNotFoundError:
        print(f"File {file_path} not found.")
        return {} if file_path.endswith('.json') else [
        ]  # Return appropriate type
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON from {file_path}: {e}")
        return {}


def save_to_file(file_path, data):
    with open(file_path, "a") as file:
        file.write(f"{data}\n")


# Logging setup
def setup_logging():
    logging.basicConfig(
        filename="bot_activity.log",
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )


def log_message(message):
    logging.info(message)
    print(message)
