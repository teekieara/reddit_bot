import praw

def get_reddit_instance():
    """Create and return a Reddit instance using PRAW."""
    return praw.Reddit(
        client_id="Lo2_zCPNEBnYxhghn_gQiQ",  # Reddit Client ID
        client_secret="PLwoo0YegVibgDLLG86bSzYq-gZiXQ",  # Reddit Client Secret
        username="QuantamHack",  # Reddit username
        password="Olafunmi2018!",  # Reddit password
        user_agent="QuantamHackBot by u/QuantamHack - A bot to explore sci-fi threads"  # User agent
    )

def fetch_subreddit_posts(reddit_instance, subreddit_name):
    """Fetch the latest posts from a given subreddit."""
    subreddit = reddit_instance.subreddit(subreddit_name)
    return subreddit.new(limit=10)  # Fetch recent posts
