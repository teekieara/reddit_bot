from reddit_api import get_reddit_instance, fetch_subreddit_posts
from functions import load_file, save_to_file, setup_logging, log_message
from keep_alive import keep_alive
import time
from utils import extract_wait_time
import praw
from debugging import setup_debugging_log, debug_print

# File paths
files_folder = "files/"
commented_posts_file = f"{files_folder}commented_posts.txt"
subs_keys_file = f"{files_folder}subs_keys.json"
sub_reddits_file = f"{files_folder}sub_reddits.txt"
commented_posts = set(load_file(commented_posts_file))  # Ensure this is a set
keywords_and_responses = load_file(subs_keys_file)

print("Loaded Keywords and Responses:", keywords_and_responses)

# Debugging
import os

# Initialize debugging log at the start
setup_debugging_log()

# Example usage in code
debug_print("Initializing the bot...")
subscribed_subreddits = load_file(sub_reddits_file)
debug_print(f"Loaded Subreddits: {subscribed_subreddits}")

reddit = get_reddit_instance()
debug_print("Reddit instance initialized.")


print("Current Working Directory:", os.getcwd())
print("Expected Path for subs_keys.json:", subs_keys_file)

subscribed_subreddits = load_file(sub_reddits_file)
print("Loaded Subreddits:", subscribed_subreddits)

# Initialize Reddit
reddit = get_reddit_instance()

# Process subreddits
import time


def process_subreddit(subreddit_name):
    log_message(f"🌌 Searching in r/{subreddit_name}...")
    try:
        for submission in fetch_subreddit_posts(reddit, subreddit_name):
            if submission.id in commented_posts_file:
                log_message(
                    f"🔄 Skipping already-commented post: {submission.id}")
                continue

            matched_keyword = next(
                (keyword for keyword in keywords_and_responses
                 if keyword.lower() in submission.title.lower()), None)

            if matched_keyword:
                response = keywords_and_responses[matched_keyword]
                try:
                    submission.reply(response)
                    log_message(f"✅ Commented on: {submission.title}")
                    save_to_file(commented_posts_file, submission.id)
                    commented_posts_file.add(submission.id)
                    time.sleep(65)  # Add a delay of 1 second between comments
                    return True  # Exit after a successful comment
                except praw.exceptions.RedditAPIException as ex:  # Avoid the generic 'e'
                    if "RATELIMIT" in str(ex):
                        wait_time = extract_wait_time(str(ex))
                        log_message(
                            f"⏳ Rate limit hit. Waiting for {wait_time} seconds..."
                        )
                        time.sleep(wait_time)
                    else:
                        log_message(f"❌ Error while commenting: {ex}")
                except Exception as ex:  # Catch any other exception
                    log_message(f"❌ Unexpected error while commenting: {ex}")

        log_message(f"🚫 No relevant posts found in r/{subreddit_name}")
    except Exception as ex:  # Avoid referencing uninitialized variables
        log_message(f"❌ Error in subreddit r/{subreddit_name}: {ex}")
    return False


for subreddit_name in subscribed_subreddits:
    process_subreddit(subreddit_name)


# Main bot loop
def run_bot():
    setup_logging()
    while True:
        for subreddit in subscribed_subreddits:
            if process_subreddit(subreddit):
                continue
        log_message("🔄 Restarting bot cycle in 1 hour...")
        time.sleep(3600)


# Start the bot
if __name__ == "__main__":
    keep_alive()
    run_bot()
