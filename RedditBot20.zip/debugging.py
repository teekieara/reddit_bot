import logging
import os

# Setup the logging configuration
def setup_debugging_log():
    if not os.path.exists("logs"):
        os.mkdir("logs")  # Create a logs folder if it doesn't exist

    logging.basicConfig(
        filename="logs/debug.log",  # Log to a file inside the logs folder
        level=logging.DEBUG,  # Set to DEBUG level
        format="%(asctime)s [%(levelname)s] %(message)s",  # Format the logs
        datefmt="%Y-%m-%d %H:%M:%S",
    )

# Log a debugging message
def log_debug_message(message):
    logging.debug(message)

# Log an info message
def log_info_message(message):
    logging.info(message)

# Log a warning message
def log_warning_message(message):
    logging.warning(message)

# Log an error message
def log_error_message(message):
    logging.error(message)

# Helper to print and log debugging messages
def debug_print(message):
    print(f"[DEBUG] {message}")  # Print to the console
    log_debug_message(message)  # Log to the file
